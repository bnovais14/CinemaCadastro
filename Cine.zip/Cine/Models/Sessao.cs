﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Cine.Models
{
    public class Sessao
    {
        [Key]
        public int ID { get; set; }

        [Required(ErrorMessage = "Preecha este campo")]
        public string NomeF { get; set; }

        [Required(ErrorMessage = "Preecha este campo")]
        public string NomeC { get; set; }


       [DataType(DataType.Time), DisplayFormat(DataFormatString = "{0: HH:mm}", ApplyFormatInEditMode = true)]
        public DateTime Hora { get; set; }

        public virtual ICollection<Cinema> Cinemas { get; set; }
        public virtual ICollection<Sessao> Sessoes { get; set; }
    }
}