﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Cine.Models
{
    public class Filmes
    {
        public int id { get; set; }
       
        [Required]
        [StringLength(30)]
        [Display(Name = "Nome")]
        public string NomeF { get; set; }
        [Required(ErrorMessage = "Preecha este campo ")]
        public string Genero { get; set; }
        [Required(ErrorMessage = "Preecha este campo ")]
        public string Indicativa { get; set; }

        [Required]
       
        public string Duraçao { get; set; }
    }
}