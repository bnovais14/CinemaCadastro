﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace Cine.Models
{
    public class Cinema
    {
        [Key]
        public int ID { get; set; }

        [Required(ErrorMessage = "Preecha este campo")]
      
        public string NomeF { get; set; }

        [Required(ErrorMessage = "Preecha este campo")]
       
        public string NomeC { get; set; }

      

        public virtual ICollection<Filmes>Filmes { get; set; }
        public virtual ICollection<Sessao> Sessoes { get; set; }

    }
}