namespace Cine.Migrations
{
    using Cine.Models;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Cine.Models.CineContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            ContextKey = "Cine.Models.CineContext";
        }

        protected override void Seed(Cine.Models.CineContext context)
        {
            var filme = new List<Filmes>
            {
                new Filmes { NomeF = "Coringa",   Genero = "Fic��o", Indicativa = "+16",
                    Dura�ao = "97" },
                new Filmes {  NomeF = "Angry Birds 2 - O Filme",   Genero = "Anima��o", Indicativa = "Livre",
                    Dura�ao = "92" },
                new Filmes { NomeF = "Abomin�vel",   Genero = "Anima��o",Indicativa = "Livre",
                    Dura�ao =  "95" },
                new Filmes {  NomeF = "Rambo: At� o Fim",   Genero = "A��o", Indicativa = "+18",
                    Dura�ao =  "89"},
                new Filmes {  NomeF = "Mal�vola - Dona do Mal",   Genero = "Aventura", Indicativa = "Livre",
                    Dura�ao = "90"},
                new Filmes {  NomeF = "Encontros",   Genero = "Romance", Indicativa = "+12",
                    Dura�ao = "110"},
                new Filmes {  NomeF = "It - Cap�tulo 2",   Genero = "Terror/Horror", Indicativa = "+16",
                    Dura�ao = "165" },
                new Filmes { NomeF = "Vai Que Cola 2 - O Come�o",   Genero = "Com�dia", Indicativa = "+12",
                    Dura�ao = "88" }
            };
            filme.ForEach(s => context.Filmes.AddOrUpdate(p => p.NomeF, s));
            context.SaveChanges();

            var cines = new List<Cinema>
            {
                new Cinema {NomeC = " Cinemark West Plaza", NomeF ="R Treze de maio, 1947 - Bela Vista",      },
                new Cinema { NomeC = "Cinemark Shopping Cidade S�o Paulos", NomeF ="Avenida Paulista, 1230 - Bela Vista", },
                new Cinema { NomeC = "Cinemark Central Plaza", NomeF ="Av. Dr. Francisco Mesquita, 1000 - Ipiranga",  },
                new Cinema {NomeC = "Cinemark SP Market",  NomeF ="Av. das Na��es Unidas, 22540 - Campo Grande",      },
                new Cinema { NomeC = "Cin�polis Itaquera", NomeF ="Estrada da Pedrira, 0 - Itaquera",    },
                new Cinema { NomeC = "Cinemark Shopping Iguatemi SP",  NomeF ="Av Brigadeiro Faria Lima, 2232 - Jardim Paulista",  },
                new Cinema {NomeC = "Cine Ara�jo Campo Limpo", NomeF ="Estrada de campo limpo, 459 - Santo Amaro",    }
            };
            cines.ForEach(s => context.Cinemas.AddOrUpdate(p => p.NomeC, s));
            context.SaveChanges();


            var ses = new List<Sessao>
            {
                new Sessao { NomeF = "Coringa", NomeC = " Cinemark West Plaza" },
                 new Sessao { NomeF = "Coringa", NomeC = "Cinemark Shopping Cidade S�o Paulos"},
                new Sessao { NomeF = "Coringa",NomeC = "Cinemark Central Plaza"},
                new Sessao { NomeF = "Angry Birds 2 - O Filme", NomeC = " Cinemark West Plaza"},
                new Sessao { NomeF = "Angry Birds 2 - O Filme",NomeC = "Cinemark Central Plaza" },
                new Sessao {NomeF = "Abomin�vel",NomeC = "Cinemark SP Market"  },
                new Sessao {NomeF = "Abomin�vel", NomeC = "Cinemark Central Plaza" },
                new Sessao { NomeF = "Rambo: At� o Fim", NomeC = "Cinemark Central Plaza" },
                new Sessao { NomeF = "Rambo: At� o Fim", NomeC = "Cinemark Shopping Cidade S�o Paulos"  },
              
                new Sessao {NomeF = "Abomin�vel", NomeC = "Cin�polis Itaquera"},
                new Sessao { NomeF = "Mal�vola - Dona do Mal",NomeC = " Cinemark West Plaza"},
                new Sessao { NomeF = "Mal�vola - Dona do Mal",NomeC = "Cinemark Shopping Iguatemi SP" },
                new Sessao {NomeF = "Encontros",NomeC = "Cinemark Shopping Iguatemi SP" },
                new Sessao {NomeF = "Encontros", NomeC = "Cin�polis Itaquera"},
                new Sessao { NomeF = "It - Cap�tulo 2", NomeC = "Cinemark Shopping Iguatemi SP" },
                new Sessao { NomeF = "It - Cap�tulo 2", NomeC = " Cinemark West Plaza" },
                new Sessao { NomeF = "It - Cap�tulo 2",  NomeC = "Cine Ara�jo Campo Limpo" },
                new Sessao { NomeF = "Vai Que Cola 2 - O Come�o",NomeC = "Cinemark Shopping Cidade S�o Paulos"  },
                new Sessao { NomeF = "Vai Que Cola 2 - O Come�o", NomeC = "Cine Ara�jo Campo Limpo" }
            };
            ses.ForEach(s => context.Sessoes.AddOrUpdate(p => p.NomeF, s));
            context.SaveChanges();

        }
    }
}