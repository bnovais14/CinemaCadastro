namespace Cine.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate1 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Cinemas", "Hora", c => c.DateTime(nullable: false));
            AddColumn("dbo.Filmes", "Cinema_ID", c => c.Int());
            AddColumn("dbo.Sessaos", "Cinema_ID", c => c.Int());
            CreateIndex("dbo.Filmes", "Cinema_ID");
            CreateIndex("dbo.Sessaos", "Cinema_ID");
            AddForeignKey("dbo.Filmes", "Cinema_ID", "dbo.Cinemas", "ID");
            AddForeignKey("dbo.Sessaos", "Cinema_ID", "dbo.Cinemas", "ID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Sessaos", "Cinema_ID", "dbo.Cinemas");
            DropForeignKey("dbo.Filmes", "Cinema_ID", "dbo.Cinemas");
            DropIndex("dbo.Sessaos", new[] { "Cinema_ID" });
            DropIndex("dbo.Filmes", new[] { "Cinema_ID" });
            DropColumn("dbo.Sessaos", "Cinema_ID");
            DropColumn("dbo.Filmes", "Cinema_ID");
            DropColumn("dbo.Cinemas", "Hora");
        }
    }
}
