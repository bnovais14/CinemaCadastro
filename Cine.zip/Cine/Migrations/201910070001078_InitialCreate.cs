namespace Cine.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Cinemas",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        NomeF = c.String(),
                        NomeC = c.String(),
                    })
                .PrimaryKey(t => t.ID);
            
            CreateTable(
                "dbo.Filmes",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        NomeF = c.String(nullable: false, maxLength: 30),
                        Genero = c.String(nullable: false),
                        Indicativa = c.Int(nullable: false),
                        Duraçao = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.Sessaos",
                c => new
                    {
                        ID = c.Int(nullable: false, identity: true),
                        NomeF = c.String(),
                        NomeC = c.String(),
                        Hora = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Sessaos");
            DropTable("dbo.Filmes");
            DropTable("dbo.Cinemas");
        }
    }
}
